(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/dev_apps_omni-fit_src_4e1d8c9e._.js",
  "static/chunks/_4b4ae0a9._.js"
],
    source: "dynamic"
});
