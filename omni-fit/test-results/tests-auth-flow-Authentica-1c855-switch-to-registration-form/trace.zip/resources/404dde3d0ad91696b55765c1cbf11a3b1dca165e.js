(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_19100b32._.js",
  "static/chunks/712e4_next_dist_compiled_react-dom_de7ddeb3._.js",
  "static/chunks/712e4_next_dist_compiled_next-devtools_index_2a55f194.js",
  "static/chunks/712e4_next_dist_compiled_5ab24996._.js",
  "static/chunks/712e4_next_dist_client_9c50e22d._.js",
  "static/chunks/712e4_next_dist_eef3fe99._.js",
  "static/chunks/712e4_@swc_helpers_cjs_55ac9573._.js"
],
    source: "entry"
});
